package com.example.tlfinal

data class UserProfile(
    var fullName: String? = null,
    var contactNo: String? = null,
    var email: String? = null,
    var username: String? = null,
    var address: String? = null
)